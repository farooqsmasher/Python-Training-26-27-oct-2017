while 1:
    print('@', end=' ')