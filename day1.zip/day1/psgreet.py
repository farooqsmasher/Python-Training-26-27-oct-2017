name = 'intuit'
city = 'bangalore'

print('name :', name)
print('city :', city)
