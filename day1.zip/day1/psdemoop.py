print('kim', end='')  # ORS
print('eva', end='')
print('tim')
print('sam')
print('allen')
print(1,2,'iii',4.4,5, sep=':')  # OFS