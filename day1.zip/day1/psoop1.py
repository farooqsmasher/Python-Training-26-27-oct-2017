import sys
import pprint
import math

class Demo:
    pass  # dummy code block


d = Demo()
print(d)
print(Demo)
print(__name__)  # default of script as well as module
print(pprint.__name__)
print(sys.__name__)
print(math.__name__)

# this
# self